import { useState } from "react";
import Topbar from "../Topbar";
import PeriodTabs from "./PeriodTabs";
import SummaryCard from "./SummaryCard";
import InitiateRemittance from "./InitiateRemittance";
import RemittanceHistory from "./RemittanceHistory";
import "./Remittance.css";

const SUMMARY_BY_PERIOD = {
  Today: { totalRides: 390, grossRevenue: 39000, oauShareOwed: 31200, xtreqMargin: 7800 },
  "This week": { totalRides: 2210, grossRevenue: 177000, oauShareOwed: 141600, xtreqMargin: 35400 },
  "This month": { totalRides: 9840, grossRevenue: 984000, oauShareOwed: 787200, xtreqMargin: 196800 },
  Custom: { totalRides: 390, grossRevenue: 39000, oauShareOwed: 31200, xtreqMargin: 7800 },
};

export default function Remittance() {
  const [period, setPeriod] = useState("Today");
  const summary = SUMMARY_BY_PERIOD[period];

  return (
    <div className="remittance-page">
      <Topbar title="Remittance Report" />

      <div className="remittance-page__content">
        <PeriodTabs onChange={setPeriod} />

        <div className="remittance-page__summary-cards">
          <SummaryCard
            label="TOTAL RIDES"
            value={summary.totalRides}
            sublabel="Completed bookings"
          />
          <SummaryCard
            label="GROSS REVENUE"
            value={`₦${summary.grossRevenue.toLocaleString()}`}
            sublabel={`${summary.totalRides} x ₦100`}
          />
          <SummaryCard
            label="OAU SHARE OWED"
            value={`₦${summary.oauShareOwed.toLocaleString()}`}
            sublabel={`${summary.totalRides} x ₦80`}
          />
          <SummaryCard
            label="XTREQ MARGIN"
            value={`₦${summary.xtreqMargin.toLocaleString()}`}
            sublabel={`${summary.totalRides} x ₦20`}
          />
        </div>

        <InitiateRemittance />
        <RemittanceHistory />
      </div>
    </div>
  );
}
