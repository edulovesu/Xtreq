import { useMemo, useState } from "react";
import Topbar from "../Topbar";
import StudentToolbar from "./StudentToolbar";
import StudentTable from "./StudentTable";
import "./StudentLookup.css";

const ALL_STUDENTS = [
  { id: 1, name: "Adebayo Tunde", email: "adebayotunde@gmail.com", trips: 10, status: "Active" },
  { id: 2, name: "Faith Emeka", email: "emekafaith@gmail.com", trips: 18, status: "Suspended" },
  { id: 3, name: "Jeremiah Banks", email: "jeremiahbanks@gmail.com", trips: 10, status: "Active" },
  { id: 4, name: "Tayo Jane", email: "tayojane02@gmail.com", trips: 0, status: "Unverified" },
];

export default function StudentLookup() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("All status");

  const filteredStudents = useMemo(() => {
    return ALL_STUDENTS.filter((student) => {
      const matchesStatus = status === "All status" || student.status === status;
      const query = search.trim().toLowerCase();
      const matchesSearch =
        !query ||
        student.name.toLowerCase().includes(query) ||
        student.email.toLowerCase().includes(query);
      return matchesStatus && matchesSearch;
    });
  }, [search, status]);

  return (
    <div className="student-lookup-page">
      <Topbar title="Student Lookup" />

      <div className="student-lookup-page__content">
        <StudentToolbar
          search={search}
          onSearchChange={setSearch}
          status={status}
          onStatusChange={setStatus}
        />
        <StudentTable students={filteredStudents} />
      </div>
    </div>
  );
}
