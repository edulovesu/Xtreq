import { useMemo, useState } from "react";
import Topbar from "../Topbar";
import RouteToolbar from "./RouteToolbar";
import RouteTable from "./RouteTable";
import RouteModal from "./RouteModal";
import "./RouteManagement.css";

const ALL_ROUTES = [
  { id: 1, from: "Gate", to: "SUB", fare: 100, status: "Active" },
  { id: 2, from: "Gate", to: "Road 7", fare: 200, status: "Active" },
  { id: 3, from: "Gate", to: "Market", fare: 200, status: "Active" },
  { id: 4, from: "Gate", to: "Halls", fare: 200, status: "Inactive" },
  { id: 5, from: "SUB", to: "Gate", fare: 100, status: "Active" },
  { id: 6, from: "Road 7", to: "Gate", fare: 200, status: "Active" },
  { id: 7, from: "Market", to: "Gate", fare: 200, status: "Active" },
  { id: 8, from: "Halls", to: "Gate", fare: 200, status: "Active" },
];

export default function RouteManagement() {
  const [routes, setRoutes] = useState(ALL_ROUTES);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("All status");
  const [modalOpen, setModalOpen] = useState(false);

  const filteredRoutes = useMemo(() => {
    return routes.filter((route) => {
      const matchesStatus = status === "All status" || route.status === status;
      const query = search.trim().toLowerCase();
      const matchesSearch =
        !query ||
        route.from.toLowerCase().includes(query) ||
        route.to.toLowerCase().includes(query);
      return matchesStatus && matchesSearch;
    });
  }, [routes, search, status]);

  const handleRegister = ({ start, end, fare, status: initialStatus }) => {
    setRoutes((prev) => [
      ...prev,
      {
        id: Date.now(), // Unique ID for table keys
        from: start,
        to: end,
        fare: Number(fare),
        status: initialStatus,
      },
    ]);
    setModalOpen(false);
  };

  return (
    <div className="route-management-page">
      <Topbar title="Route Management" />

      <div className="route-management-page__content">
        <RouteToolbar
          search={search}
          onSearchChange={setSearch}
          status={status}
          onStatusChange={setStatus}
          onAddRoute={() => setModalOpen(true)}
        />
        <RouteTable routes={filteredRoutes} />
      </div>

      <RouteModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onRegister={handleRegister}
      />
    </div>
  );
}