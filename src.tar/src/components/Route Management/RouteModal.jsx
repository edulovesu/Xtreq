import { useState } from 'react';
import { X } from 'lucide-react';
import './RouteModal.css';

const STATUS_OPTIONS = ['Active', 'Inactive'];

export default function RouteModal({ open, onClose, onRegister }) {
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [fare, setFare] = useState('');
  const [status, setStatus] = useState('Active');

  if (!open) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onRegister?.({ start, end, fare: Number(fare), status });
    setStart('');
    setEnd('');
    setFare('');
    setStatus('Active');
  };

  return (
    <div className="register-route-modal__backdrop" onClick={onClose}>
      <div
        className="register-route-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="register-route-title"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="register-route-modal__header">
          <h2 id="register-route-title" className="register-route-modal__title">
            Register New Route
          </h2>
          <button
            type="button"
            className="register-route-modal__close"
            onClick={onClose}
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>
        
        <div className="register-route-modal__divider" />

        <form onSubmit={handleSubmit}>
          <div className="register-route-modal__field">
            <label htmlFor="start">Start Location</label>
            <input
              id="start"
              type="text"
              placeholder="e.g. Gate"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              required
            />
          </div>

          <div className="register-route-modal__field">
            <label htmlFor="end">Destination</label>
            <input
              id="end"
              type="text"
              placeholder="e.g. SUB"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              required
            />
          </div>

          <div className="register-route-modal__field">
            <label htmlFor="fare">Fare (₦)</label>
            <input
              id="fare"
              type="number"
              placeholder="e.g. 100"
              value={fare}
              onChange={(e) => setFare(e.target.value)}
              required
            />
          </div>

          <div className="register-route-modal__field">
            <label htmlFor="initialStatus">Initial Status</label>
            <select
              id="initialStatus"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              {STATUS_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>

          <div className="register-route-modal__footer">
            <button
              type="button"
              className="register-route-modal__cancel"
              onClick={onClose}
            >
              Cancel
            </button>
            <button type="submit" className="register-route-modal__submit">
              Register Route
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}